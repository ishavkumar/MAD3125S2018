package com.example.macstudent.loginactivity;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ListView;

public class ReportActivity extends AppCompatActivity {

    ListView lstReport;

    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_report);


       // lstReport = findViewById(R.id.lstReport);
        //lstReport.setAdapter(new ReportAdapter())

    }
}
