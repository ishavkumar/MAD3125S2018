package com.example.macstudent.loginactivity;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.macstudent.loginactivity.R;

public class LoginActivity extends AppCompatActivity implements View.OnClickListener{

    Button btnLogin;
    Button btnRegister;
    EditText edtEmail;
    EditText edtPassword;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);


        btnLogin = findViewById(R.id.btnLogin);
        btnLogin.setOnClickListener(this);

        btnRegister = findViewById(R.id.btnRegister);
        btnRegister.setOnClickListener(this);

        edtEmail = findViewById(R.id.edtMail);
        edtPassword = findViewById(R.id.editText2);


    }

    @Override
    public void onClick(View v) {

        if (v.getId()== btnLogin.getId()) {

            String username = edtEmail.getText().toString();
            String password = edtPassword.getText().toString();

            if(username.equals("ishav.com") && password.equals("ishav")){
                Toast.makeText(this,"Login Successful",Toast.LENGTH_SHORT).show();
                startActivity(new Intent(this, HomeActivity.class));
            }else{

                Toast.makeText(this,"Invalid username/password",Toast.LENGTH_SHORT).show();
            }


            Toast.makeText(this, "LOGIN", Toast.LENGTH_SHORT).show();

        }else if(v.getId()== btnRegister.getId()){

            Toast.makeText(this, "create an account", Toast.LENGTH_SHORT).show();
            Intent signUpIntent = new Intent(this, SignUpActivity.class);
            startActivity(signUpIntent);

        }

    }
}
